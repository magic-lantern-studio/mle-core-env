/*
 * (c) Copyright IBM Corp. 2004, 2005 All Rights Reserved.
 */
package org.dita.dost.pipeline;

/**
 * None. This interface is left for future.
 * 
 * @author Lian, Li
 * 
 */
public interface AbstractPipelineOutput {

}
